(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/Fase01/Introducao.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'f1288knGz1Lx4Kq2PnGUfwO', 'Introducao', __filename);
// Script/Fase01/Introducao.js

'use strict';

// Learn cc.Class:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/class.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/class.html
// Learn Attribute:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/life-cycle-callbacks.html

cc.Class({
    extends: cc.Component,

    properties: {
        // foo: {
        //     // ATTRIBUTES:
        //     default: null,        // The default value will be used only when the component attaching
        //                           // to a node for the first time
        //     type: cc.SpriteFrame, // optional, default is typeof default
        //     serializable: true,   // optional, default is true
        // },
        // bar: {
        //     get () {
        //         return this._bar;
        //     },
        //     set (value) {
        //         this._bar = value;
        //     }
        // },
        btnOk: {
            default: null,
            type: cc.Button
        },
        btnCancel: {
            default: null,
            type: cc.Button
        },
        cursorSprite: {
            default: null,
            type: cc.Sprite
        },
        cursorAtlas: {
            default: null,
            type: cc.SpriteAtlas
        }

    },

    // LIFE-CYCLE CALLBACKS:

    onLoad: function onLoad() {
        this.node.on('mousemove', function (event) {
            this.cursorSprite.node.x = event.getLocation().x;
            this.cursorSprite.node.y = event.getLocation().y;
        }, this);

        this.node.on('touchstart', function (event) {
            this.cursorSprite.spriteFrame = this.cursorAtlas.getSpriteFrame('hand02');
        }, this);

        this.node.on('touchend', function (event) {
            this.cursorSprite.spriteFrame = this.cursorAtlas.getSpriteFrame('hand01');
        }, this);
    },
    start: function start() {

        cc.director.preloadScene("Scene/Menu");
        cc.director.preloadScene("Scene/Fase01");

        this.btnCancel.node.on('touchstart', function (event) {

            this.getComponent("SoundManager").playSoundClickBotao();
        }, this);

        this.btnOk.node.on('touchstart', function (event) {

            this.getComponent("SoundManager").playSoundClickBotao();
        }, this);

        this.btnCancel.node.on('touchend', function (event) {
            this.backToMenu();
        }, this);

        this.btnOk.node.on('touchend', function (event) {
            this.startGame();
        }, this);

        this.getComponent("SoundManager").playSoundMusicaIntroducao();
    },


    backToMenu: function backToMenu() {
        cc.director.loadScene("Scene/Menu");
    },

    startGame: function startGame() {
        cc.director.loadScene("Scene/Fase01");
    }

    // update (dt) {},
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=Introducao.js.map
        