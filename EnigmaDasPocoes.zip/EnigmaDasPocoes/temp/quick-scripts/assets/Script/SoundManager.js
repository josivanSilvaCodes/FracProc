(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/SoundManager.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '582447p2EBJuoZFbQI89062', 'SoundManager', __filename);
// Script/SoundManager.js

"use strict";

cc.Class({
    extends: cc.Component,
    properties: {
        menuMusic: {
            default: null,
            url: cc.AudioClip
        },
        introductionMusic: {
            default: null,
            url: cc.AudioClip
        },
        fase01: {
            default: null,
            url: cc.AudioClip
        },
        acertouPocao: {
            default: null,
            url: cc.AudioClip
        },
        errouPocao: {
            default: null,
            url: cc.AudioClip
        },
        clickBotao: {
            default: null,
            url: cc.AudioClip
        },
        soltouPocao: {
            default: null,
            url: cc.AudioClip
        },
        arrastandoPocao: {
            default: null,
            url: cc.AudioClip
        },

        janelaPontos: {
            default: null,
            url: cc.AudioClip
        },
        audioEnabled: true
    },

    onLoad: function onLoad() {

        //this.current = cc.audioEngine.play(this.audio, false, 1);


    },

    /*update(dt) {
    },*/

    playSoundClickBotao: function playSoundClickBotao() {

        //this.test.play();
        if (this.audioEnabled) {
            cc.audioEngine.playEffect(this.clickBotao, false);
        }
        //this.test.play();
        //  cc.audioEngine.play(coletandoPocao, true);
    },

    playSoundColetandoPocao: function playSoundColetandoPocao() {

        //this.test.play();
        if (this.audioEnabled) {
            cc.audioEngine.playEffect(this.arrastandoPocao, false);
        }
        //this.test.play();
        //  cc.audioEngine.play(coletandoPocao, true);
    },

    playSoundSoltandoPocao: function playSoundSoltandoPocao() {
        //this.test.play();
        if (this.audioEnabled) {
            cc.audioEngine.playEffect(this.soltouPocao, false);
        }
        //this.test.play();
        //  cc.audioEngine.play(coletandoPocao, true);
    },

    playSoundJanelaPontos: function playSoundJanelaPontos() {
        //this.test.play();

        if (this.audioEnabled) {

            cc.audioEngine.playEffect(this.janelaPontos, false);
        }
        //this.test.play();
        //  cc.audioEngine.play(coletandoPocao, true);
    },

    playSoundAcertouPocao: function playSoundAcertouPocao() {
        //this.test.play();

        if (this.audioEnabled) {
            cc.audioEngine.playEffect(this.acertouPocao, false);
        }
        //this.test.play();
        //  cc.audioEngine.play(coletandoPocao, true);
    },

    playSoundErrouPocao: function playSoundErrouPocao() {
        //this.test.play();

        if (this.audioEnabled) {
            cc.audioEngine.playEffect(this.errouPocao, false);
        }

        //this.test.play();
        //  cc.audioEngine.play(coletandoPocao, true);
    },

    playSoundMusicaMenu: function playSoundMusicaMenu() {
        //this.test.play();
        cc.audioEngine.stopAll();
        cc.audioEngine.playEffect(this.menuMusic, true);

        //this.test.play();
        //  cc.audioEngine.play(coletandoPocao, true);
    },

    playSoundMusicaIntroducao: function playSoundMusicaIntroducao() {
        //this.test.play();
        cc.audioEngine.stopAll();
        cc.audioEngine.playEffect(this.introductionMusic, true);

        //this.test.play();
        //  cc.audioEngine.play(coletandoPocao, true);
    },

    playSoundMusicaFase01: function playSoundMusicaFase01() {
        //this.test.play();


        cc.audioEngine.stopAll();

        cc.audioEngine.playEffect(this.fase01, true);

        //this.test.play();
        //  cc.audioEngine.play(coletandoPocao, true);
    },

    stopAllSounds: function stopAllSounds() {
        //this.test.play();

        if (this.audioEnabled == true) {
            this.audioEnabled = false;
            cc.audioEngine.pauseAll();
        } else {
            this.audioEnabled = true;
            cc.audioEngine.resumeAll();
        }
        //this.test.play();
        //  cc.audioEngine.play(coletandoPocao, true);
    }

});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=SoundManager.js.map
        